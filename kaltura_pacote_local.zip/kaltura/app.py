#!/usr/bin/env python3
"""
Aplicacao local para importar e validar vinculos de videos Kaltura.

Uso:
  python3 kaltura/app.py
  abrir http://127.0.0.1:5070
"""

from __future__ import annotations

import csv
import hashlib
import shutil
import sys
from argparse import Namespace
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
CATALOGO_CSV = BASE_DIR / "catalogo_teste_links_videos.csv"
VIDEOS_CSV = BASE_DIR / "videos_importados.csv"
VALIDACOES_CSV = BASE_DIR / "validacoes_links_videos.csv"

sys.path.insert(0, str(BASE_DIR))
import exportar_videos_catalogo as kaltura_export  # noqa: E402

app = Flask(__name__, static_folder=str(BASE_DIR / "static"))
_KS_CACHE: dict[str, Any] = {"ks": "", "criado_em": None}
_CLIENT_CACHE: dict[str, Any] = {"client": None, "criado_em": None}


VALIDACAO_CAMPOS = [
    "disc_id",
    "curso_final",
    "disciplina",
    "semestre",
    "aula",
    "playlist_id",
    "entry_id",
    "nome_video",
    "embed_url",
    "status_validacao",
    "observacao",
    "responsavel",
    "validado_em",
]


def normalizar(valor: str) -> str:
    return kaltura_export.normalizar_texto(valor)


def disc_id(curso: str, disciplina: str, semestre: str) -> str:
    bruto = f"{normalizar(curso)}|{normalizar(disciplina)}|{normalizar(semestre)}"
    return hashlib.sha1(bruto.encode("utf-8")).hexdigest()[:16]


def ler_csv(caminho: Path) -> list[dict[str, str]]:
    if not caminho.exists():
        return []
    with caminho.open(newline="", encoding="utf-8-sig") as arquivo:
        return [dict(row) for row in csv.DictReader(arquivo)]


def backup_se_existir(caminho: Path) -> None:
    if not caminho.exists():
        return
    carimbo = datetime.now().strftime("%Y%m%d-%H%M%S")
    destino = caminho.with_name(f"{caminho.stem}.backup-{carimbo}{caminho.suffix}")
    shutil.copy2(caminho, destino)


def escrever_csv(caminho: Path, campos: list[str], linhas: list[dict[str, Any]]) -> None:
    backup_se_existir(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_suffix(f".tmp-{datetime.now().strftime('%Y%m%d%H%M%S')}.csv")
    with tmp.open("w", newline="", encoding="utf-8") as arquivo:
        writer = csv.DictWriter(arquivo, fieldnames=campos, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(linhas)
    tmp.replace(caminho)


def campos_csv(caminho: Path) -> list[str]:
    if not caminho.exists():
        return []
    with caminho.open(newline="", encoding="utf-8-sig") as arquivo:
        return list(csv.DictReader(arquivo).fieldnames or [])


def mesclar_videos_por_curso(curso: str, parcial: Path) -> int:
    novas = ler_csv(parcial)
    if not curso:
        campos = campos_csv(parcial)
        escrever_csv(VIDEOS_CSV, campos, novas)
        return len(novas)

    alvo = normalizar(curso)
    antigas = [row for row in ler_csv(VIDEOS_CSV) if normalizar(row.get("curso_final", "")) != alvo]
    campos = campos_csv(parcial) or campos_csv(VIDEOS_CSV)
    escrever_csv(VIDEOS_CSV, campos, [*antigas, *novas])
    return len(antigas) + len(novas)


def catalogo_agrupado() -> dict[str, dict[str, Any]]:
    linhas = ler_csv(CATALOGO_CSV)
    grupos: dict[str, dict[str, Any]] = {}
    for row in linhas:
        curso = (row.get("curso_final") or "").strip()
        disciplina = (row.get("disciplina") or "").strip()
        semestre = (row.get("semestre") or "").strip()
        professor = (row.get("professor") or "").strip()
        playlist_id = (row.get("playlist_id") or "").strip()
        if not curso or not disciplina:
            continue

        chave = disc_id(curso, disciplina, semestre)
        grupo = grupos.setdefault(
            chave,
            {
                "disc_id": chave,
                "curso_final": curso,
                "disciplina": disciplina,
                "semestre": semestre,
                "professores": [],
                "playlist_id": playlist_id,
            },
        )
        if professor and professor not in grupo["professores"]:
            grupo["professores"].append(professor)
        if playlist_id and not grupo["playlist_id"]:
            grupo["playlist_id"] = playlist_id

    return grupos


def videos_por_disciplina() -> dict[str, list[dict[str, str]]]:
    grupos = catalogo_agrupado()
    mapa_nome = {
        (normalizar(g["curso_final"]), normalizar(g["disciplina"]), normalizar(g["semestre"])): did
        for did, g in grupos.items()
    }
    videos: dict[str, list[dict[str, str]]] = {did: [] for did in grupos}
    for row in ler_csv(VIDEOS_CSV):
        chave = (
            normalizar(row.get("curso_final", "")),
            normalizar(row.get("disciplina", "")),
            normalizar(row.get("semestre", "")),
        )
        did = mapa_nome.get(chave)
        if did:
            videos.setdefault(did, []).append(row)
    return videos


def validacoes_por_aula() -> dict[tuple[str, int], dict[str, str]]:
    validacoes: dict[tuple[str, int], dict[str, str]] = {}
    for row in ler_csv(VALIDACOES_CSV):
        try:
            aula = int(row.get("aula") or "0")
        except ValueError:
            continue
        validacoes[(row.get("disc_id", ""), aula)] = row
    return validacoes


def status_contadores(did: str, total_aulas: int, validacoes: dict[tuple[str, int], dict[str, str]]) -> dict[str, int]:
    contadores = {"correto": 0, "corrigido": 0, "vinculo_errado": 0, "sem_video": 0, "pendente": 0}
    for aula in range(1, total_aulas + 1):
        row = validacoes.get((did, aula), {})
        status = row.get("status_validacao") or "pendente"
        if status not in contadores:
            status = "pendente"
        contadores[status] += 1
    return contadores


def linha_video_para_aula(videos: list[dict[str, str]], aula: int) -> dict[str, str] | None:
    candidatos = []
    for row in videos:
        try:
            numero = int(row.get("aula") or "0")
        except ValueError:
            numero = 0
        if numero == aula:
            candidatos.append(row)
    return candidatos[0] if candidatos else None


def gerar_preview_ks() -> str:
    criado_em = _KS_CACHE.get("criado_em")
    if _KS_CACHE.get("ks") and criado_em:
        idade = (datetime.now() - criado_em).total_seconds()
        if idade < 3300:
            return str(_KS_CACHE["ks"])

    kaltura_export.carregar_env(BASE_DIR / ".env")
    (
        KalturaClient,
        KalturaConfiguration,
        _KalturaFilterPager,
        _KalturaPlaylistFilter,
        KalturaSessionType,
    ) = kaltura_export.importar_kaltura()
    secret = kaltura_export.os.environ.get("KALTURA_ADMIN_SECRET")
    if not secret:
        return ""

    config = KalturaConfiguration()
    config.serviceUrl = kaltura_export.SERVICE_URL_PADRAO
    client = KalturaClient(config)
    ks = client.session.start(
        secret,
        "pipeline-kaltura-preview",
        KalturaSessionType.ADMIN,
        kaltura_export.PARTNER_ID_PADRAO,
        3600,
        "appId:pipeline-kaltura-preview",
    )
    _KS_CACHE["ks"] = ks
    _KS_CACHE["criado_em"] = datetime.now()
    return str(ks)


def preview_client():
    criado_em = _CLIENT_CACHE.get("criado_em")
    if _CLIENT_CACHE.get("client") and criado_em:
        idade = (datetime.now() - criado_em).total_seconds()
        if idade < 3300:
            return _CLIENT_CACHE["client"]

    kaltura_export.carregar_env(BASE_DIR / ".env")
    args = Namespace(
        admin_secret_env="KALTURA_ADMIN_SECRET",
        service_url=kaltura_export.SERVICE_URL_PADRAO,
        partner_id=kaltura_export.PARTNER_ID_PADRAO,
        expiry=3600,
    )
    client = kaltura_export.criar_client(args)
    _CLIENT_CACHE["client"] = client
    _CLIENT_CACHE["criado_em"] = datetime.now()
    return client


def url_preview(embed_url: str) -> str:
    if not embed_url:
        return ""
    try:
        ks = gerar_preview_ks()
    except Exception:
        return embed_url
    if not ks:
        return embed_url

    partes = urlsplit(embed_url)
    query = dict(parse_qsl(partes.query, keep_blank_values=True))
    query["ks"] = ks
    query["flashvars[ks]"] = ks
    return urlunsplit((partes.scheme, partes.netloc, partes.path, urlencode(query), partes.fragment))


def url_video_preview(entry_id: str) -> str:
    if not entry_id:
        return ""
    try:
        client = preview_client()
        flavors = client.flavorAsset.getByEntryId(entry_id)
        candidatos = [
            f for f in flavors
            if getattr(f, "fileExt", "") == "mp4" and int(getattr(f, "size", 0) or 0) > 0
        ]
        if not candidatos:
            return ""
        candidatos.sort(key=lambda f: int(getattr(f, "bitrate", 0) or 0), reverse=True)
        return str(client.flavorAsset.getUrl(candidatos[0].id))
    except Exception:
        return ""


def montar_aulas(did: str) -> list[dict[str, Any]]:
    grupos = catalogo_agrupado()
    videos = videos_por_disciplina().get(did, [])
    validacoes = validacoes_por_aula()
    grupo = grupos[did]

    numeros_importados = []
    for row in videos:
        try:
            numero = int(row.get("aula") or "0")
        except ValueError:
            numero = 0
        if numero > 0:
            numeros_importados.append(numero)
    total = max([8, *numeros_importados] if numeros_importados else [8])

    aulas = []
    for numero in range(1, total + 1):
        importado = linha_video_para_aula(videos, numero) or {}
        validacao = validacoes.get((did, numero), {})
        entry_id = validacao.get("entry_id") or importado.get("entry_id") or ""
        embed_url = validacao.get("embed_url") or importado.get("embed_url") or ""
        nome_video = validacao.get("nome_video") or importado.get("nome_video") or ""
        playlist_id = validacao.get("playlist_id") or importado.get("playlist_id") or grupo.get("playlist_id", "")
        status_importacao = importado.get("kaltura_status") or ("sem_video" if not entry_id else "ok")
        status_validacao = validacao.get("status_validacao") or ("sem_video" if not entry_id else "pendente")
        aulas.append(
            {
                "disc_id": did,
                "aula": numero,
                "playlist_id": playlist_id,
                "entry_id": entry_id,
                "embed_url": embed_url,
                "preview_embed_url": "",
                "preview_video_url": "",
                "nome_video": nome_video,
                "tags": importado.get("tags", ""),
                "duracao_seg": importado.get("duracao_seg", ""),
                "thumbnail_url": importado.get("thumbnail_url", ""),
                "status_importacao": status_importacao,
                "status_validacao": status_validacao,
                "observacao": validacao.get("observacao", ""),
                "responsavel": validacao.get("responsavel", ""),
                "validado_em": validacao.get("validado_em", ""),
            }
        )
    return aulas


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/catalogo")
def api_catalogo():
    grupos = catalogo_agrupado()
    videos = videos_por_disciplina()
    validacoes = validacoes_por_aula()
    cursos: dict[str, list[dict[str, Any]]] = {}

    for did, grupo in grupos.items():
        numeros = []
        for row in videos.get(did, []):
            try:
                numero = int(row.get("aula") or "0")
            except ValueError:
                numero = 0
            if numero > 0:
                numeros.append(numero)
        total_aulas = max([8, *numeros] if numeros else [8])
        item = {
            **grupo,
            "professores": " | ".join(grupo["professores"]),
            "total_aulas": total_aulas,
            "contadores": status_contadores(did, total_aulas, validacoes),
            "videos_importados": len([v for v in videos.get(did, []) if v.get("entry_id")]),
        }
        cursos.setdefault(grupo["curso_final"], []).append(item)

    for lista in cursos.values():
        lista.sort(key=lambda x: (x["semestre"], x["disciplina"].lower()))

    return jsonify({"cursos": sorted(cursos), "disciplinas": cursos})


@app.route("/api/disciplina/<did>")
def api_disciplina(did: str):
    grupos = catalogo_agrupado()
    if did not in grupos:
        return jsonify({"erro": "Disciplina nao encontrada"}), 404

    videos = videos_por_disciplina().get(did, [])
    sem_match = [v for v in videos if (v.get("kaltura_status") == "sem_match")]
    return jsonify(
        {
            "disciplina": {
                **grupos[did],
                "professores": " | ".join(grupos[did]["professores"]),
            },
            "aulas": montar_aulas(did),
            "sem_match": sem_match,
        }
    )


@app.route("/api/preview/<entry_id>")
def api_preview(entry_id: str):
    embed_url = kaltura_export.build_embed_url(
        kaltura_export.PARTNER_ID_PADRAO,
        kaltura_export.UICONF_ID_PADRAO,
        entry_id,
    )
    return jsonify(
        {
            "entry_id": entry_id,
            "embed_url": embed_url,
            "preview_embed_url": url_preview(embed_url),
            "preview_video_url": url_video_preview(entry_id),
        }
    )


@app.route("/api/importar", methods=["POST"])
def api_importar():
    dados = request.get_json(silent=True) or {}
    limite = int(dados.get("limite_disciplinas") or 0)
    curso = str(dados.get("curso") or "").strip()
    try:
        saida = VIDEOS_CSV
        if curso:
            saida = BASE_DIR / f"videos_importados.tmp-{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        args = Namespace(
            entrada=CATALOGO_CSV,
            saida=saida,
            env=BASE_DIR / ".env",
            admin_secret_env="KALTURA_ADMIN_SECRET",
            partner_id=kaltura_export.PARTNER_ID_PADRAO,
            uiconf_id=kaltura_export.UICONF_ID_PADRAO,
            service_url=kaltura_export.SERVICE_URL_PADRAO,
            expiry=86400,
            limite_playlists=20,
            curso=curso,
            limite_disciplinas=limite,
        )
        kaltura_export.exportar(args)
        total_linhas = mesclar_videos_por_curso(curso, saida)
        if saida != VIDEOS_CSV and saida.exists():
            saida.unlink()
    except SystemExit as exc:
        return jsonify({"ok": False, "erro": str(exc)}), 400
    except Exception as exc:  # noqa: BLE001 - erro precisa voltar para a tela.
        return jsonify({"ok": False, "erro": str(exc)}), 500

    return jsonify({"ok": True, "saida": str(VIDEOS_CSV), "linhas": total_linhas})


@app.route("/api/validar", methods=["POST"])
def api_validar():
    dados = request.get_json(silent=True) or {}
    did = str(dados.get("disc_id") or "")
    grupos = catalogo_agrupado()
    if did not in grupos:
        return jsonify({"ok": False, "erro": "Disciplina nao encontrada"}), 404

    try:
        aula = int(dados.get("aula") or "0")
    except ValueError:
        aula = 0
    if aula <= 0:
        return jsonify({"ok": False, "erro": "Aula invalida"}), 400

    status = str(dados.get("status_validacao") or "pendente")
    permitidos = {"pendente", "correto", "corrigido", "vinculo_errado", "sem_video"}
    if status not in permitidos:
        return jsonify({"ok": False, "erro": "Status invalido"}), 400

    aulas = {item["aula"]: item for item in montar_aulas(did)}
    atual = aulas.get(aula, {})
    grupo = grupos[did]
    entry_id = str(dados.get("entry_id") or atual.get("entry_id") or "").strip()
    embed_url = str(dados.get("embed_url") or atual.get("embed_url") or "").strip()
    if entry_id and not embed_url:
        embed_url = kaltura_export.build_embed_url(
            kaltura_export.PARTNER_ID_PADRAO,
            kaltura_export.UICONF_ID_PADRAO,
            entry_id,
        )

    nova = {
        "disc_id": did,
        "curso_final": grupo["curso_final"],
        "disciplina": grupo["disciplina"],
        "semestre": grupo["semestre"],
        "aula": aula,
        "playlist_id": str(dados.get("playlist_id") or atual.get("playlist_id") or grupo.get("playlist_id", "")),
        "entry_id": entry_id,
        "nome_video": str(dados.get("nome_video") or atual.get("nome_video") or "").strip(),
        "embed_url": embed_url,
        "status_validacao": status,
        "observacao": str(dados.get("observacao") or "").strip(),
        "responsavel": str(dados.get("responsavel") or "").strip(),
        "validado_em": datetime.now().isoformat(timespec="seconds"),
    }

    linhas = ler_csv(VALIDACOES_CSV)
    linhas = [
        row
        for row in linhas
        if not (row.get("disc_id") == did and str(row.get("aula")) == str(aula))
    ]
    linhas.append(nova)
    linhas.sort(key=lambda r: (r.get("curso_final", ""), r.get("disciplina", ""), int(r.get("aula") or 0)))
    escrever_csv(VALIDACOES_CSV, VALIDACAO_CAMPOS, linhas)
    return jsonify({"ok": True, "validacao": nova})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5070, debug=True)
