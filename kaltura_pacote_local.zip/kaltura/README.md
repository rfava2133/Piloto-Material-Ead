# Validador Kaltura UNIGRAN

Aplicacao local para validar se o video encontrado na Kaltura corresponde a
cada aula da disciplina.

## Fluxo do responsavel

1. Abrir o app.
2. Selecionar o curso.
3. Clicar em `Importar links`.
4. Selecionar a disciplina.
5. Conferir o video de cada aula.
6. Clicar em:
   - `Vinculo correto`: o video pertence a aula.
   - `Vinculo errado`: o video nao pertence a aula.

Aulas sem video importado sao tratadas automaticamente como `sem_video`.

## Para que serve `Importar links`

O botao consulta a API da Kaltura para o curso selecionado. Ele:

1. procura a playlist de cada disciplina;
2. le os videos dentro da playlist;
3. tenta identificar a aula pelo nome ou tag do video;
4. atualiza `videos_importados.csv`.

O numero ao lado do botao e um limite de teste. Use:

- `0`: importa o curso inteiro;
- `5`: importa apenas 5 disciplinas, para teste rapido.

## Resultado final

A tabela final da conferencia e:

```text
validacoes_links_videos.csv
```

Coluna principal:

```text
status_validacao
```

Valores:

- `correto`: aprovado pelo responsavel.
- `vinculo_errado`: precisa revisar/corrigir.
- `sem_video`: a aula nao tem video importado.

Colunas importantes:

- `curso_final`
- `disciplina`
- `semestre`
- `aula`
- `entry_id`
- `nome_video`
- `embed_url`
- `responsavel`
- `validado_em`
- `observacao`

## Teste com Empreendedorismo

Abra `validacoes_links_videos.csv` e filtre:

```text
curso_final = Administracao
disciplina = Empreendedorismo
```

Veja a coluna:

```text
status_validacao
```

## Arquivos

- `app.py`: servidor local Flask.
- `exportar_videos_catalogo.py`: importador da API Kaltura.
- `static/index.html`: interface.
- `catalogo_teste_links_videos.csv`: catalogo base do teste.
- `videos_importados.csv`: links importados da Kaltura.
- `validacoes_links_videos.csv`: conferencia humana.
- `.env`: segredo local da Kaltura. Nao enviar para GitHub.
- `.env.example`: modelo sem segredo real.

## Nuvem ou servidor interno

Para responsavel remoto, GitHub sozinho nao basta, porque ele so versiona o
codigo. O app precisa rodar em algum lugar.

Opcao recomendada para UNIGRAN:

1. GitHub privado para o codigo.
2. Servidor interno ou VM da UNIGRAN para rodar o Flask.
3. Acesso por VPN ou rede interna.
4. `KALTURA_ADMIN_SECRET` configurado como variavel de ambiente no servidor.
5. Pasta persistente ou banco para salvar `validacoes_links_videos.csv`.

Para piloto local, CSV resolve. Para uso com mais de uma pessoa ao mesmo tempo,
o ideal e trocar o CSV por banco ou Google Sheets.
